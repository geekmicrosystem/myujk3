<?php 
    $hostname = 'localhost';
    $username = 'root';
    $password = '';
    $db = 'ujk';

    $conn = mysqli_connect($hostname, $username, $password, $db);
?>